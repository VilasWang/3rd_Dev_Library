#include <qsqldriverplugin.h>
#include <qstringlist.h> 
#include "qsql_sqlite_p.h"

QT_BEGIN_NAMESPACE

class QSQLitecipherDriverPlugin : public QSqlDriverPlugin 
{ 
	Q_OBJECT
	Q_PLUGIN_METADATA(IID "org.qt-project.Qt.QSqlDriverFactoryInterface" FILE "sqlitecipher.json")

public:         
	QSQLitecipherDriverPlugin();

	QSqlDriver* create(const QString &) Q_DECL_OVERRIDE;
};   

QSQLitecipherDriverPlugin::QSQLitecipherDriverPlugin() 
	: QSqlDriverPlugin() 
{

}

QSqlDriver* QSQLitecipherDriverPlugin::create(const QString &name) 
{         
	if (name == QLatin1String("QSQLITECIPHER"))
	{
		QSQLiteDriver* driver = new QSQLiteDriver();            
		return driver; 
	}
	return 0; 
}

QT_END_NAMESPACE

#include "smain.moc"