quazip-0.7.3
zlib_1.2.8
vs2010
Qt5.5.1